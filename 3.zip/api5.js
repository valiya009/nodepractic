const express = require('express');
const app = express();
app.use(express.json());

let movies = [];

app.get('/movies', (req, res) => {
    res.json(movies)
});

app.post('/movies', (req, res) => {
    const { title, genre, director } = req.body;
    const newmovies = { id: movies.length + 1, title, genre, director }
    movies.push(newmovies);
    res.status(200).json(newmovies)
});

app.put('/movies/:id', (req, res) => {
    const moviesid = parseInt(req.params.id);
    const { genre, director } = req.body;
    const moviesit = movies.find(m => m.id === moviesid)
    if (moviesit) {
        moviesit.genre = genre || moviesit.genre;
        moviesit.director = director || moviesit.director;
        res.json(moviesit);

    }
    else {
        res.status(200).json({ message: "cart item not found" });
    }
});

app.delete('/movies/:id', (req, res) => {
    const moviesid = parseInt(req.params.id);
    const index = movies.findIndex(m => m.id === moviesid);
    if (index !== -1) {
        movies.splice(index, 1);
        res.status(200).json({ message: "item delete successfully" });

    }
    else {
        res.status(200).json({ message: "item not found" });
    }
})

app.listen(3000, () => {
    console.log("server listening on port  3000");

});