const express = require('express');
const app = express();
const url = "mongodb+srv://valiya009:valiya009@cluster0.fr80v.mongodb.net/testdata?retryWrites=true&w=majority&appName=Cluster0";
app.use(express.json());

let profile = [];

app.get('/profile', (req, res) => {
    res.json(profile);
});

app.post('/profile', (req, res) => {
    const { name, age, email } = req.body;
    const newProfile = { id: profile.length + 1, name, age, email };
    profile.push(newProfile);
    res.status(201).json(newProfile);
});

app.put('/profile/:id', (req, res) => {
    const { name, age, email } = req.body;
    const profileId = parseInt(req.params.id);
    const profiles = profile.find(p => p.id === profileId);
    if (profiles) {
        profiles.name = name || profiles.name;
        profiles.age = age || profiles.age;
        profiles.email = email || profiles.email;
        res.json(profiles);
    } else {
        res.status(404).json({ message: 'Profile not found' });
    }
});

app.delete('/profile/:id', (req, res) => {
    const profileId = parseInt(req.params.id);
    const index = profile.findIndex(p => p.id === profileId);
    if (index !== -1) {
        profile.splice(index, 1);
        res.json({ message: 'Profile deleted' });
    } else {
        res.status(404).json({ message: 'Profile not found' });
    }
});

app.listen(4500, () => {
    console.log("server listening on 4500");

});