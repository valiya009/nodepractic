const express = require('express');
const app = express();
app.use(express.json());

let cart = [];

app.get('/cart', (req, res) => {
    res.json(cart)
});

app.post('/cart', (req, res) => {
    const { item, quality, price } = req.body;
    const newcart = { id: cart.length + 1, item, quality, price }
    cart.push(newcart);
    res.status(200).json(newcart)
});

app.put('/cart/:id', (req, res) => {
    const cartid = parseInt(req.params.id);
    const { quality, price } = req.body;
    const cartitem = cart.find(c => c.id === cartid)
    if (cartitem) {
        cartitem.quality = quality || cartitem.quality;
        cartitem.price = price || cartitem.price;
        res.json(cartitem);

    }
    else {
        res.status(200).json({ message: "cart item not found" });
    }
});

app.delete('/cart/:id', (req, res) => {
    const cartid = parseInt(req.params.id);
    const index = cart.findIndex(c => c.id === cartid);
    if (index !== -1) {
        cart.splice(index, 1);
        res.status(200).json({ message: "item delete successfully" });

    }
    else {
        res.status(200).json({ message: "item not found" });
    }
})

app.listen(3000, () => {
    console.log("server listening on port  3000");

});