const express = require('express');
const app = express();
app.use(express.json());


let post = [];

app.get('/post', (req, res) => {
    res.json(post);

});

app.post('/post', (req, res) => {
    const { title, content, author } = req.body;
    const newPost = {
        id: post.length + 1, title, content, author, createdAt: new Date()
    };
    post.push(newPost);
    res.status(201).json(newPost);
});

app.put('/post/:id', (req, res) => {
    const postId = parseInt(req.params.id);
    const { title, content } = req.body;
    const posts = post.find(p => p.id === postId);
    if (posts) {
        posts.title = title || posts.title;
        posts.content = content || posts.content;
        res.json(posts);
    } else {
        res.status(404).json({ message: 'Post not found' });
    }
});

app.delete('/post/:id', (req, res) => {
    const postid = parseInt(req.params.id);
    const index = post.findIndex(p => p.id === postid);
    if (index !== -1) {
        post.splice(index, 1);
        res.json({ message: 'post deleted' });
    } else {
        res.status(404).json({ message: 'post not found' });
    }
});

app.listen(5000, () => {
    console.log("server listening on 4500");

});