const { log } = require('console');
const fs = require('fs');

const content = 'this is my data i wanr to write in my form';
fs.writeFile('op.txt', content, (err) => {
    if (err) {
        console.log("error in file system", err);
        return;

    }
    console.log("file save successfully");

});