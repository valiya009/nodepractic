const fs = require('fs');
const filePath = 'example.txt'

if (fs.existsSync(filePath)) {
    console.log(`${filePath} exists.`);
}
else {
    console.log(`${filePath} does not exist.`);
}

