const fs = require('fs');
const oldFileName = 'example.txt';
const newFileName = 'template.txt';
fs.rename(oldFileName, newFileName, (err) => {
    if (err) {
        console.error('Error renaming the file:', err);
        return;
    }
    console.log(`File renamed from ${oldFileName} to ${newFileName}`);
});
