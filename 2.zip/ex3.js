
const fs = require('fs');

const content = ' this is uppend data i want to delete my data';
fs.appendFile('op.txt', content, (err) => {
    if (err) {
        console.log("error in file system", err);
        return;

    }
    console.log("file append successfully");

});