const express = require('express');
const app = express();
// Middleware to track request time
app.use((req, res, next) => {
    const start = Date.now(); // Record the start time

    res.on('finish', () => {

        const duration = Date.now() - start; // Calculate the time taken
        console.log(`Request to ${req.url} took ${duration}ms`);
    });

    next(); // Pass control to the next middleware or route
});
app.get('/', (req, res) => {
    setInterval(() => {
        res.send('Hello, World!');
    }, 3000)

});
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});