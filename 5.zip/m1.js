const express = require('express');
const app = express();





// Example: 'aB3Xy7hQ'


app.use((req, res, next) => {
    const currentDate = new Date();
    console.log(`[${currentDate}] ${req.method} request to ${req.url}`);
    next();
});
app.get('/', (req, res) => {


    res.send('Hello, World!');
});
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
