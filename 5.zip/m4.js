const express = require('express');
const app = express();
// Simulate an error in a route
app.get('/error', (req, res, next) => {
    const error = new Error('Something went wrong!');
    next(error); // Pass the error to the next middleware
});
// Error handling middleware
// app.use((err, req, res, next) => {
//     console.error(err.message);
//     res.status(500).json({ message: 'Internal Server Error', error: err.message });
// });
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
