const express = require('express');
const app = express();


app.use((req, res, next) => {
    if (req.method === 'POST' && req.body) {
        req.body.processedData = `Processed: ${req.body.data}`;
    }
    next();
});
app.post('/process-data', express.json(), (req, res) => {
    res.json({ original: req.body.data, processed: req.body.processedData });
});
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
