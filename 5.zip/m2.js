const { log } = require('console');
const express = require('express');
const app = express();
app.use(express.json())

const tocken = "6N4v775D4scTyV4MHe3l5qI5"

function generateUniqueId(length = 24) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let uniqueId = '';
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        uniqueId += characters.charAt(randomIndex);
    }
    return uniqueId;
}

console.log(generateUniqueId());

const authenticate = (req, res, next) => {
    const temp = req.body.token
    console.log(req.body);

    if (temp === '0jjTyfkt04e4GJLMo2pQld0z') {
        next();
    }
    else {
        res.status(401).json({ meassage: " uthorisation invalied token" });
    }
};

app.post('/dashboard', authenticate, (req, res) => {
    res.send('Welcome to the Dashboard!');
});

app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});