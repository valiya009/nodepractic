const mongoose = require('mongoose');

function connect() {
    mongoose.connect('mongodb+srv://valiya009:valiya009@cluster0.fr80v.mongodb.net/problem?retryWrites=true&w=majority&appName=Cluster0', {
        useNewUrlparser: true,
        useUnifiedTopology: true,
    })
};

module.exports = connect

