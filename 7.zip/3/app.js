const dbconnect = require('./dbconnrction/dbconect.js');
const task = require('./model/model1.js')
const mongoose = require('mongoose');
const express = require('express');
const app = express();


app.use(express.json());
dbconnect();
app.post('/tasks', async (req, res) => {
    const { title, discription, deadline } = req.body;
    const newtask = new task({ title, discription, deadline })
    await newtask.save();
    res.status(200).json({ message: "task inserted succefully!" })
});


app.get('/tasks', async (req, res) => {
    const tasks = await task.find({ status: "inprogress" });
    res.json(tasks);
});

app.put('/tasks/:id/status', async (req, res) => {
    const { status } = req.body;
    const updatedtask = await task.findByIdAndUpdate(
        req.params.id,
        { status },
        { new: true }
    );
    res.json(updatedtask);
})

app.listen(5000);
