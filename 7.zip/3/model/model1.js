const mongoose = require('mongoose');
const mongooseSchema = mongoose.Schema({
    title: {
        require: true,
        type: String
    },
    discription: {
        require: true,
        enum: ['To-Do', 'In Progress', 'Completed'],
        type: String
    },
    deadline: Date,
    status: {
        type: String,
        default: "inprogress"
    }
});


const task = mongoose.model('tasks', mongooseSchema);

module.exports = task;