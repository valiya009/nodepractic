const mongoose = require('mongoose');
const express = require('express');
const product = require('./model/product.js');
const dotenv = require('dotenv');
const app = express();
const dbconnect = require('./dbconnection/dbconnection.js');
const { config } = require('process');

app.use(express.json());





app.get('/product', async (req, res) => {
    const { category, minprice, maxprice } = req.body;
    const match = {};
    const newproduct = new product({ name, category, price, stocks });
    if (category) match.category = category;
    if (minprice || maxprice) {
        match.price = {};
    }
    if (minprice) {
        match.price.$gte = parseFloat(minprice)
    }
    if (maxprice) {
        match.price.$ite = parseFloat(maxprice)
    }

    const products = await product.aggregate([
        { $match: match },
        { $sort: { price: 1 } },
        { $project: { name: 1, category: 1, price: 1 } }
    ]);
    res.status(200).json(products)

    const product = await product
});

app.post('/products', async (req, res) => {
    const { name, category, price, stocks } = req.body;
    const newproduct = new product({ name, category, price, stocks })
    await newproduct.save()
    res.status(200).json({ message: 'Data Inserted Succefully', newproduct });
});




app.listen(3000, () => {
    console.log("server running on port 3000");

})