const mongoose = require('mongoose');
const { type } = require('os');


const productSchema = new mongoose.Schema({
    name: {
        require: true,
        type: String
    },
    category: {
        require: true,
        type: String
    },
    price: {
        require: true,
        type: String
    },
    stocks: {
        require: true,
        type: String
    }
})

const product = mongoose.model('product', productSchema);

module.exports = product;