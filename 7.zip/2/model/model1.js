const mongoose = require('mongoose');
const mongooseSchema = mongoose.Schema({
    title: {
        require: true,
        type: String
    },
    discription: {
        require: true,
        enum: ['To-Do', 'In Progress', 'Completed'],
        type: String
    },
    deadline: Date,
});


const task = mongoose.model('tasks', mongooseSchema);

export default tasks;