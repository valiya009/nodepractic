const dbconnect = require('./dbconnrction/dbconect.js');
const task = require('./model/model1.js')
const mongoose = require('mongoose');
const express = require('express');
const app = express();


app.use(express.json());

app.post('/tasks', async (req, res) => {
    const { tital, deascription, deadline } = req.body;
    const newtask = newtask({ tital, deascription, deadline })
    await newtask.save();
    res.status(200).json({ message: "task inserted succefully!" })
});



dbconnection();
