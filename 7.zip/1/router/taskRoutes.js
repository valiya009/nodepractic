import express from 'express';
import Task from '../model/task.js';
import { authenticate } from '../middleware/authMiddleware.js';

const router = express.Router();

//task user post method
router.post('/task', authenticate, async (req, res) => {
    const { title } = req.body;
    const newTask = new Task({ title, userId: req.userId });
    await newTask.save();
    res.status(201).json(newTask);
});

// Get user's tasks
router.get('/tasks', authenticate, async (req, res) => {
    const tasks = await Task.find({ userId: req.userId });
    res.json(tasks);
});

// Update task
router.put('/tasks/:id', authenticate, async (req, res) => {
    const { title, completed } = req.body;
    const updatedTask = await Task.findByIdAndUpdate(
        req.params.id,
        { title, completed },
        { new: true }
    );
    res.json(updatedTask);
});

// Delete task
router.delete('/tasks/:id', authenticate, async (req, res) => {
    await Task.findByIdAndDelete(req.params.id);
    res.json({ message: 'Task deleted' });
});

export default router;
