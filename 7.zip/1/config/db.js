import mongoose from 'mongoose';

export const connectDB = () => {
    mongoose.connect('mongodb+srv://valiya009:valiya009@cluster0.fr80v.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')  // Use MongoDB's default port 27017
        .then(() => console.log('MongoDB connected'))
        .catch((err) => console.error('Error connecting to MongoDB:', err));
};
