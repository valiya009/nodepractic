const express = require('express');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const app = express();
app.use(express.json());
// Connect to MongoDB
mongoose.connect('mongodb+srv://valiya009:valiya009@cluster0.fr80v.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});
// Mongoose Schemas and Models
const userSchema = new mongoose.Schema({
    username: String,
    password: String,
});
const User = mongoose.model('User', userSchema);
const taskSchema = new mongoose.Schema({
    title: String,
    completed: { type: Boolean, default: false },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
});
const Task = mongoose.model('Task', taskSchema);
// User registration
app.post('/register', async (req, res) => {
    const { username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ username, password: hashedPassword });
    await newUser.save();
    res.status(201).json({ message: 'User registered' });
});
// User login (returns JWT)
app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (user && await bcrypt.compare(password, user.password)) {
        const token = jwt.sign({ userId: user._id }, 'secretKey');
        res.json({ token });
    } else {
        res.status(401).json({ message: 'Invalid credentials' });
    }
});
// Middleware to verify JWT token
const authenticate = (req, res, next) => {
    const token = req.headers['authorization'];
    if (!token) return res.status(403).json({ message: 'No token provided' });
    jwt.verify(token, 'secretKey', (err, decoded) => {
        if (err) return res.status(401).json({ message: 'Invalid token' });
        req.userId = decoded.userId;
        next();
    });
};
// Create task
app.post('/tasks', authenticate, async (req, res) => {
    const { title } = req.body;
    const newTask = new Task({ title, userId: req.userId });
    await newTask.save();
    res.status(201).json(newTask);
});
// Get user's tasks
app.get('/tasks', authenticate, async (req, res) => {
    const tasks = await Task.find({ userId: req.userId });
    res.json(tasks);
});
// Update task
app.put('/tasks/:id', authenticate, async (req, res) => {
    const { title, completed } = req.body;
    const updatedTask = await Task.findByIdAndUpdate(
        req.params.id,
        { title, completed },
        { new: true }
    );
    res.json(updatedTask);
});
// Delete task
app.delete('/tasks/:id', authenticate, async (req, res) => {
    await Task.findByIdAndDelete(req.params.id);
    res.json({ message: 'Task deleted' });
});
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
