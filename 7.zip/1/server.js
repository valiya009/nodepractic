import express from 'express';
import mongoose from 'mongoose';
import userRoutes from './router/userRoutes.js';
import taskRoutes from './router/taskRoutes.js';
import { connectDB } from './config/db.js';

const app = express();

// Middleware to parse JSON
app.use(express.json());

// Connect to MongoDB
connectDB();

// Routes
app.use('/api/v1/users', userRoutes);  // User routes
app.use('/api/v1/tasks', taskRoutes);  // Task routes

// Start the server
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
