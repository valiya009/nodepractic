const countdownStart = parseInt(process.argv[2]);
if (isNaN(countdownStart) || countdownStart <= 0) {
    console.log('Usage: node countdown.js <startNumber>');
    process.exit(1);
}
console.log('Countdown started:');
for (let i = countdownStart; i >= 0; i--) {
    console.log(i);
}
