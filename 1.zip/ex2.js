const word = process.argv[2];
const repeatCount = parseInt(process.argv[3]);

if (!word || isNaN(repeatCount)) {
    console.log('Usage: node wordRepeater.js <word> <repeatCount>');
    process.exit(1);
}
for (let i = 0; i < repeatCount; i++) {
    console.log(word);
}
