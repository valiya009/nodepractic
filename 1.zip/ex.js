const name = process.argv[2];

if (!name) {
    console.log("Please Provide Your Name!");
    process.exit(1)

}
console.log(`hello , ${name}! welcome to node.js`);
