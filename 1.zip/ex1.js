const args = process.argv.slice(2);

const num1 = parseFloat(args[0]);
const oprator = args[1];
const num2 = parseFloat([args[2]]);

if (!num1 || !num2 || !oprator) {
    console.log(` Usage node calculator.js , <num1><oprator><num2>`);
    process.exit(1)
}

let result;

switch (oprator) {
    case '+':
        result = num1 + num2;
        break;

    case '-':
        result = num1 - num2;
        break;

    case '*':
        result = num1 * num2;
        break;

    case '/':
        result = num1 / num2;
        break;

    case '%':
        result = num1 % num2;
        break;

    default:
        console.log("invalied oprator use. + , - , * , / or %");
        process.exit(1)

}
console.log(`result, ${num1} ${oprator} ${num2} = ${result}`);

