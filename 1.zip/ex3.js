const foods = process.argv.slice(2);

if (foods.length === 0) {
    console.log("please provide your letest favorite foods ");
    process.exit(1);
}

console.log("your favorite foods are:");
foods.forEach((food, index) => {

    console.log(`${index + 1}. ${food}`);


});
