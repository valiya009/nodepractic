import express from 'express';
import mongoose from 'mongoose';
import userrout from './router/user.js';
import tasksrouter from './router/task.js';
import connectDB from './dbconnection.js';

const app = express();

app.use(express.json());

app.use("/api/v1", userrout);
app.use("/api/v1", tasksrouter);

connectDB();
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
