import express from 'express'
import tasks from '../controler/task.js';

const router = express.Router();

router.post("/task/register", tasks);

export default tasksrouter;