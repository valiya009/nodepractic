import Task from "../model/taskSchema.js";


app.post('/tasks', authenticate, async (req, res) => {
    const { title } = req.body;
    const newTask = new Task({ title, userId: req.userId });
    await newTask.save();
    res.status(201).json(newTask);
});
// Get user's tasks
app.get('/tasks', authenticate, async (req, res) => {
    const tasks = await Task.find({ userId: req.userId });
    res.json(tasks);
});
// Update task
app.put('/tasks/:id', authenticate, async (req, res) => {
    const { title, completed } = req.body;
    const updatedTask = await Task.findByIdAndUpdate(
        req.params.id,
        { title, completed },
        { new: true }
    );
    res.json(updatedTask);
});
// Delete task
app.delete('/tasks/:id', authenticate, async (req, res) => {
    await Task.findByIdAndDelete(req.params.id);
    res.json({ message: 'Task deleted' });
});
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});

export default tasks;
