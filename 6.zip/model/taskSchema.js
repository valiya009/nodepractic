const taskSchema = new mongoose.Schema({
    title: String,
    completed: { type: Boolean, default: false },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
});
const Task = mongoose.model('Task', taskSchema);

export default Task;






